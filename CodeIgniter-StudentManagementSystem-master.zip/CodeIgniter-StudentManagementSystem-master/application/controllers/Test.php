<?php 
   class Test extends CI_Controller {
  
      public function idex() { 
         echo "Hello World!"; 
      } 
   } 
?>