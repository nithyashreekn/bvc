# Student Management System
Using CodeIgniter framework, mysql database, and bootstrap.